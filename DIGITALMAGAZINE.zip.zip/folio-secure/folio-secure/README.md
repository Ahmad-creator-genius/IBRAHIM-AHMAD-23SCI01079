# Folio Secure: digital magazine web app
Node.js + Express + SQLite. Readers browse and search published stories. Admins publish and manage them.


## Security (where each item lives in `server.js`)
| Requirement | Implementation |
|---|---|
| Authentication, logout | `/login`, `/register`, `/logout` |
| Password hashing | bcryptjs, cost 12 |
| Roles and access control | `need()` middleware (`user`/`admin`), checked on every route |
| SQL injection | prepared statements only |
| XSS | `textContent` rendering in `public/app.js` and Helmet CSP |
| Sessions | express-session, HttpOnly, SameSite=Strict, Secure in production, 1h, regenerated at login |
| CSRF | per-session token header on all state-changing requests |
| Validation | `text()` helper, email regex, password rules, body size limit |
| Sensitive data | secrets in `.env`, hashes never sent to the client, generic errors |
| HTTPS | HTTP-to-HTTPS redirect and HSTS when `NODE_ENV=production` |

## Test plan (fill in the Actual and Status columns when you run each case)
| Test | Expected | Actual | Status |
|---|---|---|---|
| Valid login | Dashboard shown | | |
| Wrong password | Generic error | | |
| Empty or invalid registration | Validation message | | |
| Weak password | Rejected | | |
| `' OR 1=1 --` in login and search | No bypass | | |
| `<script>alert(1)</script>` as a story title | Shown as text, nothing runs | | |
| User opens `#/admin` or calls `/api/users` | Access denied (403) | | |
| POST without CSRF token | 403 | | |
| 21 rapid login attempts | Rate limit message | | |
| Phone width (360px) | No sideways scrolling | | |
| Stop the database file | Generic error, details in server log | | |
`npm test` automates the API rows above.

## Deployment
1. Choose a host (Render, Railway, Fly.io or a VPS) with Node 20+ and a persistent disk for `DB_PATH`.
2. Set environment variables: `NODE_ENV=production`, `SESSION_SECRET` (`openssl rand -hex 32`), `ADMIN_EMAIL`, `ADMIN_PASSWORD`, `DB_PATH`.
3. Build `npm install --omit=dev`, start `npm start`. Put the app behind HTTPS (the host's certificate, or Nginx with Let's Encrypt) and point your domain at it.
4. Backups: copy the SQLite file on a schedule (`sqlite3 folio.db ".backup backup.db"`) and store it off the server. Test a restore.
5. Monitoring: read server logs (`console.error` output) and the Admin audit log. Rotate the admin password after first login.
6. Known production upgrade: swap the default in-memory session store for `connect-sqlite3` or Redis so logins survive restarts.

## Review (complete after testing)
What it does, features, security measures, test results, performance notes, problems met, limitations (no password reset, no email verification, no image uploads, single-server sessions), future improvements.
