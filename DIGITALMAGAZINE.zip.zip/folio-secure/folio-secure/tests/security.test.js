// Start the server first (npm start), then run: npm test   (BASE=https://your-domain to test a live site)
const {test}=require('node:test'),assert=require('node:assert');
const B=process.env.BASE||'http://localhost:3000';
const client=()=>{let c='',t='';return async(p,m='GET',b,tok=true)=>{const r=await fetch(B+'/api'+p,{method:m,headers:{'content-type':'application/json',cookie:c,...(tok&&t?{'x-csrf-token':t}:{})},body:b&&JSON.stringify(b)});
  const sc=r.headers.get('set-cookie');if(sc)c=sc.split(';')[0];const d=await r.json().catch(()=>({}));if(d.csrf)t=d.csrf;return{s:r.status,d}}};
const email='t'+Date.now()+'@test.com',pw='Passw0rd-12345';
test('unauthenticated access is blocked',async()=>{assert.equal((await client()('/articles')).s,401)});
test('weak password rejected',async()=>{const a=client();await a('/me');assert.equal((await a('/register','POST',{name:'Tim',email,password:'short'})).s,400)});
test('register, then login works',async()=>{const a=client();await a('/me');assert.equal((await a('/register','POST',{name:'Tim',email,password:pw})).s,201);
  const b=client();await b('/me');assert.equal((await b('/login','POST',{email,password:pw})).s,200)});
test('wrong password gives generic 401',async()=>{const a=client();await a('/me');assert.equal((await a('/login','POST',{email,password:'wrong-Pass-123'})).s,401)});
test('SQL injection login fails',async()=>{const a=client();await a('/me');assert.equal((await a('/login','POST',{email:"' OR 1=1 --",password:"' OR '1'='1"})).s,401)});
test('missing CSRF token rejected',async()=>{const a=client();await a('/me');assert.equal((await a('/login','POST',{email,password:pw},false)).s,403)});
test('normal user cannot use admin routes',async()=>{const a=client();await a('/me');await a('/login','POST',{email,password:pw});
  assert.equal((await a('/users')).s,403);assert.equal((await a('/articles','POST',{title:'x',issue:'x',author:'x',body:'x'})).s,403)});
test('SQL injection in search returns safely',async()=>{const a=client();await a('/me');await a('/login','POST',{email,password:pw});
  const r=await a('/articles?q='+encodeURIComponent("' OR 1=1 --"));assert.equal(r.s,200);assert.ok(Array.isArray(r.d))});
