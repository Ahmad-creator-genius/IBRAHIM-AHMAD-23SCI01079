// All dynamic content is inserted with textContent / text nodes (never innerHTML) => XSS-safe by construction.
let csrf='',me=null;const $=s=>document.querySelector(s),view=$('#view');
const h=(t,a={},...k)=>{const e=document.createElement(t);for(const[n,v]of Object.entries(a))n.startsWith('on')?e.addEventListener(n.slice(2),v):e.setAttribute(n,v);e.append(...k);return e};
async function api(p,m='GET',b){const r=await fetch('/api'+p,{method:m,headers:{'Content-Type':'application/json','x-csrf-token':csrf},body:b&&JSON.stringify(b)});
  const d=await r.json().catch(()=>({}));if(!r.ok)throw new Error(d.error||'Request failed');return d}
const show=(...n)=>view.replaceChildren(...n),msg=(t,ok)=>h('p',{class:ok?'ok':'err',role:'alert'},t);
const goto=hash=>{location.hash=hash;route()};
function form(fields,btn,onsub){const out=h('div');
  const f=h('form',{},...fields.map(([n,l,t,x={}])=>h('label',{},l,t==='textarea'?h('textarea',{name:n,maxlength:20000,...x}):h('input',{name:n,type:t||'text',required:'',...x}))),h('button',{},btn),out);
  f.addEventListener('submit',async e=>{e.preventDefault();out.replaceChildren();try{await onsub(Object.fromEntries(new FormData(f)),f)}catch(x){out.replaceChildren(msg(x.message))}});return f}
function nav(){const l=(href,t)=>h('a',{href},t);$('#nav').replaceChildren(...(me?[l('#/','Dashboard'),l('#/profile','Profile'),...(me.role==='admin'?[l('#/admin','Admin')]:[]),l('#/security','Security'),
  h('button',{onclick:async()=>{await api('/logout','POST');const r=await api('/me');csrf=r.csrf;me=null;nav();goto('#/login')}},'Log out')]:[l('#/login','Log in'),l('#/register','Register'),l('#/security','Security')]))}
const session=r=>{csrf=r.csrf;me=r.user;nav();goto('#/')};
const pages={
'/login':()=>show(h('h1',{},'Log in'),form([['email','Email','email'],['password','Password','password']],'Log in',async d=>session(await api('/login','POST',d)))),
'/register':()=>show(h('h1',{},'Create account'),form([['name','Name'],['email','Email','email'],['password','Password (10+ characters, letters and numbers)','password',{minlength:10}]],'Register',async d=>session(await api('/register','POST',d)))),
'/':async()=>{const iss=await api('/issues'),q=h('input',{type:'search',placeholder:'Search stories',maxlength:60,'aria-label':'Search'}),
  sel=h('select',{'aria-label':'Issue'},h('option',{value:''},'All issues'),...iss.map(i=>h('option',{value:i},i))),list=h('div',{class:'grid'});
  const load=async()=>{const a=await api('/articles?q='+encodeURIComponent(q.value)+'&issue='+encodeURIComponent(sel.value));
    list.replaceChildren(...(a.length?a.map(x=>h('a',{class:'card',href:'#/read/'+Number(x.id)},h('small',{},x.issue+(x.published?'':' (draft)')),h('h3',{},x.title),h('p',{},x.excerpt+'…'),h('small',{},'By '+x.author))):[h('p',{},'No stories match.')]))};
  q.addEventListener('input',load);sel.addEventListener('change',load);show(h('h1',{},'Hello, '+me.name),h('div',{class:'bar'},q,sel),list);load()},
'/read':async id=>{const a=await api('/articles/'+Number(id));show(h('small',{},a.issue),h('h1',{},a.title),h('small',{},'By '+a.author),h('p',{class:'body'},a.body),h('p',{},h('a',{href:'#/'},'Back')))},
'/profile':()=>show(h('h1',{},'Profile'),h('p',{},'Email: '+me.email),h('p',{},'Role: '+me.role),form([['name','Display name','text',{value:me.name,minlength:2,maxlength:60}]],'Save name',async d=>{const r=await api('/me','PATCH',d);me=r.user;nav();view.append(msg('Saved',true))})),
'/admin':async()=>{const[users,arts,log]=await Promise.all([api('/users'),api('/articles'),api('/log')]);
  const tbl=(cols,rows)=>h('table',{},h('tr',{},...cols.map(c=>h('th',{},c))),...rows.map(r=>h('tr',{},...r.map(c=>h('td',{},c instanceof Node?c:String(c))))));
  const act=(t,fn)=>h('button',{onclick:async()=>{try{await fn();pages['/admin']()}catch(e){alert(e.message)}}},t);
  show(h('h1',{},'Admin'),h('h2',{},'New story'),form([['title','Headline'],['issue','Issue'],['author','Author'],['body','Story text','textarea',{required:''}]],'Publish',async d=>{await api('/articles','POST',{...d,published:true});pages['/admin']()}),
  h('h2',{},'Stories'),tbl(['Title','Status',''],arts.map(a=>[a.title,a.published?'Published':'Draft',h('span',{},act(a.published?'Unpublish':'Publish',async()=>{const f=await api('/articles/'+a.id);await api('/articles/'+a.id,'PUT',{...f,published:!f.published})}),act('Delete',()=>api('/articles/'+a.id,'DELETE')))])),
  h('h2',{},'Users'),tbl(['Name','Email','Role'],users.map(u=>[u.name,u.email,u.role])),h('h2',{},'Audit log'),tbl(['Time','Event','User'],log.map(l=>[l.ts,l.event,l.user_id??''])))},
'/security':()=>show(h('h1',{},'Security measures'),h('ul',{class:'sec'},...[
 ['Password hashing','bcrypt (cost 12). Plain passwords are never stored or logged.'],
 ['SQL injection','Every query uses prepared statements with bound parameters, including search.'],
 ['XSS','The interface writes user content as text nodes only, and a Content-Security-Policy blocks inline scripts.'],
 ['Sessions','HttpOnly, SameSite=Strict, Secure (production) cookie; 1-hour expiry; session ID regenerated at login; destroyed at logout.'],
 ['CSRF','A per-session token is required on every POST, PUT, PATCH and DELETE.'],
 ['Access control','Login is checked on every API route and the Admin role is checked on the server, not just hidden in the menu.'],
 ['Input validation','Types, lengths, email format and password strength are validated on the server.'],
 ['Brute force','Login and registration are rate-limited. Login errors never reveal whether an email exists.'],
 ['Secrets and transport','Secrets live in environment variables. Production forces HTTPS and sends HSTS and other Helmet headers.'],
 ['Errors and audit','Users see generic errors; details go to the server log. Logins, denials and admin actions are written to an audit table.']
].map(([a,b])=>h('li',{},h('b',{},a+': '),b))))};
async function route(){const[,p,arg]=location.hash.slice(1).split('/'),key='/'+(p||'');
  const open=['/login','/register','/security'];try{if(!me&&!open.includes(key))return goto('#/login');await(pages[key]||pages['/'])(arg)}catch(e){show(msg(e.message))}}
addEventListener('hashchange',route);
(async()=>{const r=await api('/me');csrf=r.csrf;me=r.user;nav();route()})();
