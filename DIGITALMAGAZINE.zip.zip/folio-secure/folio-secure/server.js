require('dotenv').config();
const express=require('express'),session=require('express-session'),helmet=require('helmet'),rateLimit=require('express-rate-limit'),
bcrypt=require('bcryptjs'),crypto=require('crypto'),Database=require('better-sqlite3');
const prod=process.env.NODE_ENV==='production';
if(prod&&!process.env.SESSION_SECRET)throw new Error('SESSION_SECRET is required in production');
const db=new Database(process.env.DB_PATH||'folio.db');db.pragma('journal_mode=WAL');
db.exec(`CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY,email TEXT UNIQUE NOT NULL,name TEXT NOT NULL,hash TEXT NOT NULL,role TEXT NOT NULL DEFAULT 'user');
CREATE TABLE IF NOT EXISTS articles(id INTEGER PRIMARY KEY,title TEXT NOT NULL,issue TEXT NOT NULL,author TEXT NOT NULL,body TEXT NOT NULL,published INTEGER NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS log(id INTEGER PRIMARY KEY,ts TEXT NOT NULL,event TEXT NOT NULL,user_id INTEGER)`);
const audit=(e,uid)=>db.prepare('INSERT INTO log(ts,event,user_id) VALUES(?,?,?)').run(new Date().toISOString(),e,uid??null);
if(!db.prepare('SELECT 1 FROM users').get()&&process.env.ADMIN_EMAIL&&process.env.ADMIN_PASSWORD){
  db.prepare('INSERT INTO users(email,name,hash,role) VALUES(?,?,?,?)').run(process.env.ADMIN_EMAIL.toLowerCase(),'Admin',bcrypt.hashSync(process.env.ADMIN_PASSWORD,12),'admin');
  db.prepare('INSERT INTO articles(title,issue,author,body,published) VALUES(?,?,?,?,1)').run('Welcome to Folio','Issue 1','Admin','Your first published story.\n\nLog in as admin to add more.');
}
const app=express();
if(prod)app.set('trust proxy',1);
app.use(helmet());
if(prod)app.use((req,res,n)=>req.secure?n():res.redirect(301,'https://'+req.headers.host+req.url));
app.use(express.json({limit:'30kb'}));
app.use(session({name:'folio.sid',secret:process.env.SESSION_SECRET||crypto.randomBytes(32).toString('hex'),resave:false,saveUninitialized:false,
  cookie:{httpOnly:true,sameSite:'strict',secure:prod,maxAge:60*60*1000}}));
app.use(express.static('public'));

const api=express.Router();app.use('/api',api);
const limiter=rateLimit({windowMs:15*60*1000,limit:20,standardHeaders:true,legacyHeaders:false,message:{error:'Too many attempts. Try again later.'}});
const pub=u=>({id:u.id,email:u.email,name:u.name,role:u.role});
const text=(v,min,max)=>typeof v==='string'&&v.trim().length>=min&&v.trim().length<=max?v.trim():null;

// CSRF: every state-changing request must carry the per-session token
api.use((req,res,n)=>{
  req.session.csrf??=crypto.randomBytes(24).toString('hex');
  if(!['GET','HEAD'].includes(req.method)){
    const a=Buffer.from(req.get('x-csrf-token')||''),b=Buffer.from(req.session.csrf);
    if(a.length!==b.length||!crypto.timingSafeEqual(a,b))return res.status(403).json({error:'Invalid CSRF token'});
  }
  req.user=req.session.uid?db.prepare('SELECT id,email,name,role FROM users WHERE id=?').get(req.session.uid):null;
  n();
});
// Access control: authentication + role check, enforced server-side
const need=role=>(req,res,n)=>{
  if(!req.user)return res.status(401).json({error:'Please log in'});
  if(role&&req.user.role!==role){audit('access_denied:'+req.path,req.user.id);return res.status(403).json({error:'Access denied'});}
  n();
};
const start=(req,res,u,evt,code=200)=>req.session.regenerate(err=>{ // new session id on login prevents fixation
  if(err)return res.status(500).json({error:'Server error'});
  req.session.uid=u.id;req.session.csrf=crypto.randomBytes(24).toString('hex');audit(evt,u.id);
  res.status(code).json({user:pub(u),csrf:req.session.csrf});
});
api.get('/me',(req,res)=>res.json({user:req.user,csrf:req.session.csrf}));

api.post('/register',limiter,async(req,res)=>{
  const name=text(req.body.name,2,60),email=text(req.body.email,5,120)?.toLowerCase(),pw=req.body.password;
  if(!name||!email||!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))return res.status(400).json({error:'Enter a valid name and email'});
  if(typeof pw!=='string'||pw.length<10||pw.length>100||!/[a-zA-Z]/.test(pw)||!/\d/.test(pw))return res.status(400).json({error:'Password needs 10+ characters with letters and numbers'});
  const hash=await bcrypt.hash(pw,12);
  try{const r=db.prepare("INSERT INTO users(email,name,hash,role) VALUES(?,?,?,'user')").run(email,name,hash);
    start(req,res,{id:r.lastInsertRowid,email,name,role:'user'},'register',201);
  }catch(e){console.error(e.message);res.status(e.code?.startsWith('SQLITE_CONSTRAINT')?409:500).json({error:'Could not register with those details'});}
});
const DUMMY=bcrypt.hashSync('timing-equaliser',12);
api.post('/login',limiter,async(req,res)=>{
  const email=String(req.body.email||'').toLowerCase().trim(),pw=String(req.body.password||'');
  const u=db.prepare('SELECT * FROM users WHERE email=?').get(email); // parameterised: no SQL injection
  const ok=await bcrypt.compare(pw,u?u.hash:DUMMY);
  if(!u||!ok){audit('login_failed',u?.id);return res.status(401).json({error:'Invalid email or password'});}
  start(req,res,u,'login');
});
api.post('/logout',need(),(req,res)=>{const id=req.user.id;req.session.destroy(()=>{audit('logout',id);res.clearCookie('folio.sid');res.json({ok:true});});});
api.patch('/me',need(),(req,res)=>{
  const name=text(req.body.name,2,60);if(!name)return res.status(400).json({error:'Enter a valid name'});
  db.prepare('UPDATE users SET name=? WHERE id=?').run(name,req.user.id);res.json({user:{...req.user,name}});
});

const art=b=>{const title=text(b.title,1,120),issue=text(b.issue,1,40),author=text(b.author,1,60),body=text(b.body,1,20000);
  return title&&issue&&author&&body?{title,issue,author,body,published:b.published?1:0}:null;};
api.get('/issues',need(),(req,res)=>res.json(db.prepare('SELECT DISTINCT issue FROM articles WHERE published=1 OR ?=1 ORDER BY issue').all(req.user.role==='admin'?1:0).map(r=>r.issue)));
api.get('/articles',need(),(req,res)=>{
  const q='%'+String(req.query.q||'').slice(0,60)+'%',i=String(req.query.issue||'').slice(0,40),adm=req.user.role==='admin'?1:0;
  res.json(db.prepare(`SELECT id,title,issue,author,published,substr(body,1,140) AS excerpt FROM articles
    WHERE (title LIKE ? OR body LIKE ?) AND (?='' OR issue=?) AND (?=1 OR published=1) ORDER BY id DESC`).all(q,q,i,i,adm));
});
api.get('/articles/:id',need(),(req,res)=>{
  const a=db.prepare('SELECT * FROM articles WHERE id=?').get(Number(req.params.id));
  if(!a||(!a.published&&req.user.role!=='admin'))return res.status(404).json({error:'Not found'});res.json(a);
});
api.post('/articles',need('admin'),(req,res)=>{const a=art(req.body);if(!a)return res.status(400).json({error:'Check all fields'});
  const r=db.prepare('INSERT INTO articles(title,issue,author,body,published) VALUES(@title,@issue,@author,@body,@published)').run(a);audit('article_create',req.user.id);res.status(201).json({id:r.lastInsertRowid});});
api.put('/articles/:id',need('admin'),(req,res)=>{const a=art(req.body);if(!a)return res.status(400).json({error:'Check all fields'});
  db.prepare('UPDATE articles SET title=@title,issue=@issue,author=@author,body=@body,published=@published WHERE id=@id').run({...a,id:Number(req.params.id)});res.json({ok:true});});
api.delete('/articles/:id',need('admin'),(req,res)=>{db.prepare('DELETE FROM articles WHERE id=?').run(Number(req.params.id));audit('article_delete',req.user.id);res.json({ok:true});});
api.get('/users',need('admin'),(req,res)=>res.json(db.prepare('SELECT id,email,name,role FROM users ORDER BY id').all()));
api.get('/log',need('admin'),(req,res)=>res.json(db.prepare('SELECT ts,event,user_id FROM log ORDER BY id DESC LIMIT 50').all()));
api.use((req,res)=>res.status(404).json({error:'Not found'}));
app.use((err,req,res,n)=>{console.error(new Date().toISOString(),err.message);const s=err.status&&err.status<500?err.status:500;res.status(s).json({error:s<500?'Bad request':'Server error'});});
app.listen(process.env.PORT||3000,()=>console.log('Folio running on port '+(process.env.PORT||3000)));
